// Fungsi untuk mengupdate tanggal dan hari secara otomatis
function updateDateTime() {
    const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
    const now = new Date();
    const indonesiaTime = new Date(now.toLocaleString("en-US", { timeZone: "Asia/Jakarta" }));
    const dayOfWeek = indonesiaTime.toLocaleDateString('id-ID', { weekday: 'long' });
    const month = indonesiaTime.toLocaleDateString('id-ID', { month: 'long' });
    const date = indonesiaTime.getDate();
    const year = indonesiaTime.getFullYear();

    // Format tanggal untuk ditampilkan di dalam link
    const formattedDate = `${dayOfWeek} ${date} ${month} ${year}`;

    // Update tanggal di dalam semua link
    document.querySelectorAll('.date-placeholder').forEach(function(element) {
        element.textContent = formattedDate;
    });

    // Update link berdasarkan tanggal dan hari
    document.querySelectorAll('.link').forEach(function(element) {
        let href = element.getAttribute('href');
        let text = element.textContent.trim();

        // Menentukan bagian prediksi berdasarkan judul
        let predictionType = '';
        if (text.includes('Singapore')) {
            predictionType = 'singapore';
        } else if (text.includes('Hongkong')) {
            predictionType = 'hongkong';
        } else if (text.includes('Sydney')) {
            predictionType = 'sydney';
        } else if (text.includes('Cambodia')) {
            predictionType = 'cambodia';
        } else if (text.includes('China')) {
            predictionType = 'china';
        }

        // Membuat URL dinamis
        if (predictionType) {
            href = `/prediksi-syair-${predictionType}.html`;
        }

        element.setAttribute('href', href);
    });
}

// Menjalankan fungsi saat halaman dimuat
window.onload = updateDateTime;
