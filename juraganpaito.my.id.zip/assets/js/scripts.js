$(function(){
	$(".btn-close").click(function(){
		$(this).parents('[class^="banner-"]').hide();
		return false;
	});
});