<?php
header('Access-Control-Allow-Origin: *'); // Izinkan permintaan dari mana saja
header('Content-Type: text/plain'); // Pastikan format yang dikirim adalah teks

$url = 'http://178.128.111.185/prediksi-chinapools/';

// Gunakan cURL jika file_get_contents() tidak berfungsi
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
$content = curl_exec($ch);
curl_close($ch);

if ($content !== false) {
    $first_step = explode('<div class="mb-2" style="text-align: center">', $content);
    
    if (isset($first_step[1])) {
        $second_step = explode("</div>", $first_step[1]);
        $text1 = $second_step[0];
        echo $text1;
    } else {
        echo "Data tidak ditemukan.";
    }
} else {
    echo "Gagal mengambil data.";
}
?>